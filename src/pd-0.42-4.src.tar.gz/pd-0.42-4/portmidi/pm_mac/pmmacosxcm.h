/* system-specific definitions */

PmError pm_macosxcm_init(void);
void pm_macosxcm_term(void);